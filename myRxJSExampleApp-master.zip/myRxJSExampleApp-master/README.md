# myRxJSExampleApp
An example of using RxJS in an Angular/NativeScript app
